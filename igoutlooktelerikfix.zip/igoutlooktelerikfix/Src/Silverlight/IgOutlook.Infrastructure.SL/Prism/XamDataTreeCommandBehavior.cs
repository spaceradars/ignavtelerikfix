﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Practices.Prism.Commands;
using Telerik.Windows.Controls;

namespace IgOutlook.Infrastructure.Prism
{
    public class XamDataTreeCommandBehavior : CommandBehaviorBase<RadTreeView>
    {
        public XamDataTreeCommandBehavior(RadTreeView tree)
            : base(tree)
        {
            tree.SelectionChanged +=tree_SelectionChanged;
        }

        void tree_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (e.AddedItems.Count > 0)
            {
                var param = e.AddedItems[0] as INavigationItem;                
                if (param != null)
                    CommandParameter = param.NavigationPath;
                else
                    CommandParameter = String.Empty;

                ExecuteCommand();
            }
            
        }
    }
}
