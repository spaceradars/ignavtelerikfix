﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using IgOutlook.Infrastructure;

namespace IgOutlook
{
    public partial class Shell : UserControl
    {
        public Shell(ShellViewModel viewModel)
        {
            InitializeComponent();
            DataContext = viewModel;
        }

        private void XamOutlookBar_SelectedGroupChanged(object sender, Infragistics.Controls.Menus.SelectedGroupChangedEventArgs e)
        {
            var group = e.NewSelectedOutlookBarGroup as IOutlookBarGroup;
            if (group != null)
            {
                Commands.NavigateCommand.Execute(group.DefaultNavigationPath);
            }
        }
    }
}
