﻿using IgOutlook.Infrastructure;
using IgOutlook.Infrastructure.Prism;
using IgOutlook.Modules.Mail.Menus;
using IgOutlook.Modules.Mail.Views;
using Microsoft.Practices.Prism.Regions;
using Microsoft.Practices.Unity;

namespace IgOutlook.Modules.Mail
{
    public class MailModule : ModuleBase
    {
        public MailModule(IUnityContainer container, IRegionManager regionManager)
            : base (container, regionManager)
        {

        }

        protected override void RegisterTypes()
        {
            Container.RegisterTypeForNavigation<DefaultView>();
            Container.RegisterTypeForNavigation<MailView>();
            Container.RegisterType<IMailViewViewModel, MailViewViewModel>();
        }

        protected override void ResolveOutlookGroup()
        {
            RegionManager.Regions[RegionNames.OutlookBarGroupRegion].Add(Container.Resolve<MailGroup>());
        }
    }
}
