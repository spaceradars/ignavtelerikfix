﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Infragistics.Controls.Menus;
using IgOutlook.Infrastructure;

namespace IgOutlook.Modules.Mail.Menus
{
    public partial class MailGroup : OutlookBarGroup, IOutlookBarGroup
    {
        public MailGroup(MailGroupViewModel viewModel)
        {
            InitializeComponent();
            DataContext = viewModel;
        }

        public string DefaultNavigationPath
        {
            get
            {
                var item = _xamDataTree.SelectionSettings.SelectedNodes[0] as XamDataTreeNode;
                if (item != null)
                    return ((INavigationItem)item.Data).NavigationPath;
                else
                    return typeof(IgOutlook.Modules.Mail.Views.DefaultView).FullName;
            }
        }
    }
}
