﻿using IgOutlook.Infrastructure;
using IgOutlook.Modules.Mail.Views;
using Microsoft.Practices.Prism;
using System.Collections.ObjectModel;

namespace IgOutlook.Modules.Mail.Menus
{
    public class MailGroupViewModel : ViewModelBase
    {
        private ObservableCollection<NavigationItem> _items;
        public ObservableCollection<NavigationItem> Items
        {
            get { return _items; }
            set
            {
                _items = value;
                OnPropertyChanged("Items");
            }
        }

        public MailGroupViewModel()
        {
            GenerateMenu();
        }

        private void GenerateMenu()
        {
            Items = new ObservableCollection<NavigationItem>();

            var root = new NavigationItem() { Caption = "Personal Folders", NavigationPath = typeof(DefaultView).FullName };
            root.Items.Add(new NavigationItem() { Caption = "Inbox", NavigationPath = CreateNavigationPath(NavigationParameters.Inbox) });
            root.Items.Add(new NavigationItem() { Caption = "Drafts", NavigationPath = CreateNavigationPath(NavigationParameters.Drafts) });
            root.Items.Add(new NavigationItem() { Caption = "Sent Items", NavigationPath = CreateNavigationPath(NavigationParameters.Sent) });
            root.Items.Add(new NavigationItem() { Caption = "Deleted Items", NavigationPath = CreateNavigationPath(NavigationParameters.Deleted) });

            Items.Add(root);
        }


        private string CreateNavigationPath(string folder)
        {
            UriQuery query = new UriQuery();
            query.Add(NavigationParameters.FolderKey, folder);
            return typeof(MailView).FullName + query;
        }
    }
}
