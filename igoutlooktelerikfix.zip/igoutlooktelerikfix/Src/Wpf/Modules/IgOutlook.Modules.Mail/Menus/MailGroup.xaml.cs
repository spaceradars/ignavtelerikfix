﻿using IgOutlook.Infrastructure;
using IgOutlook.Modules.Mail.Views;
using Telerik.Windows.Controls;

namespace IgOutlook.Modules.Mail.Menus
{
    /// <summary>
    /// Interaction logic for MailGroup.xaml
    /// </summary>
    public partial class MailGroup : RadOutlookBarItem
    {
        public MailGroup(MailGroupViewModel viewModel)
        {
            InitializeComponent();
            DataContext = viewModel;
        }

        public string DefaultNavigationPath
        {
            get
            {
                return "Mail";
                //var item = _xamDataTree.SelectionSettings.SelectedNodes[0] as RadTreeVie;
                //if (item != null)
                //    return ((INavigationItem)item.Data).NavigationPath;
                //else
                //    return typeof(DefaultView).FullName;
            }
        }
    }
}
