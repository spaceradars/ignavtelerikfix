﻿using IgOutlook.Infrastructure;
using Telerik.Windows.Controls;

namespace IgOutlook
{
    /// <summary>
    /// Interaction logic for Shell.xaml
    /// </summary>
    public partial class Shell : RadRibbonWindow
    {
        public Shell(ShellViewModel viewModel)
        {
            InitializeComponent();
            DataContext = viewModel;
        }


        private void RadOutlookBar_SelectionChanged(object sender, Telerik.Windows.Controls.RadSelectionChangedEventArgs e)
        {
            var group = ((RadOutlookBar)sender).SelectedItem as RadOutlookBarItem;
            if (group != null)
            {
                Commands.NavigateCommand.Execute("enter path here");
            }
        }
    }
}
