﻿using System.ComponentModel;

namespace IgOutlook.Infrastructure
{
    public class ViewModelBase : IViewModel, INotifyPropertyChanged
    {
        private string _title;
        public string Title
        {
            get { return _title; }
            set
            {
                _title = value;
                OnPropertyChanged("Title");
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string propertyName)
        {
            var handler = PropertyChanged;
            handler?.Invoke(this, new PropertyChangedEventArgs(propertyName));
            //if (handler != null)
            //    handler(this, new PropertyChangedEventArgs(propertyName));
            // equivalent

        }
    }
}
