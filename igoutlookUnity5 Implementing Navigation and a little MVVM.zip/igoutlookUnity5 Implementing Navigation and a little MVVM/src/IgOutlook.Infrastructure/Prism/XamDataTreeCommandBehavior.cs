﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Prism.Interactivity;
using Telerik.Windows.Controls;

namespace IgOutlook.Infrastructure.Prism
{
    public class XamDataTreeCommandBehavior : CommandBehaviorBase<RadTreeView>
    {
        public XamDataTreeCommandBehavior(RadTreeView tree)
            : base(tree)
        {
            tree.SelectionChanged += TreeActive_NodeChanged;
        }

        void TreeActive_NodeChanged(object sender, SelectionChangedEventArgs e)
        {
            //-SelectedItems   Count = 1   System.Collections.ObjectModel.ObservableCollection < object > { Telerik.Windows.Controls.SelectionChanger<object>}
            //+       [0] { IgOutlook.Infrastructure.NavigationItem}
            //object { IgOutlook.Infrastructure.NavigationItem}

            RadTreeView newSelectedItem = e.Source as RadTreeView;
            //// get the list of the added items to selection
            //IList addedItems = e.AddedItems;

            //// get the list of the removed items from the selection
            //IList removedItems = e.RemovedItems;

            //// get a reference to the RadTreeView
            //RadTreeView treeView = (sender as RadTreeView);
            var param = newSelectedItem.SelectedItem as INavigationItem;
            if (param != null)
                CommandParameter = param.NavigationPath;
            else
                CommandParameter = string.Empty;

            ExecuteCommand(CommandParameter);
        }
    }
}
