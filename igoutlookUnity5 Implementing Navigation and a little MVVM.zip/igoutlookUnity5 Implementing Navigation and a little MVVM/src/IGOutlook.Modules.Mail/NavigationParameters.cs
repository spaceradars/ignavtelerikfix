﻿
namespace IgOutlook.Modules.Mail
{
    public class NavigationParametersInfo
    {
        public const string FolderKey = "Folder";

        public const string Inbox = "Inbox";
        public const string Drafts = "Drafts";
        public const string Sent = "Sent";
        public const string Deleted = "Deleted";
    }
}
