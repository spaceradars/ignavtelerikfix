﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using IgOutlook.Infrastructure;
using System.Collections.ObjectModel;
using IgOutlook.Modules.Mail.Views;
using Prism.Regions;

namespace IgOutlook.Modules.Mail.Menus
{
    public class MailGroupViewModel : ViewModelBase
    {
        private ObservableCollection<NavigationItem> _items;
        public ObservableCollection<NavigationItem> Items
        {
            get { return _items; }
            set
            {
                _items = value;
                OnPropertyChanged("Items");
            }
        }

        public MailGroupViewModel()
        {
            GenerateMenu();
        }

        private void GenerateMenu()
        {
            Items = new ObservableCollection<NavigationItem>();

            var root = new NavigationItem() { Caption = "Personal Folders", NavigationPath = typeof(DefaultView).FullName };
            root.Items.Add(new NavigationItem() { Caption = "Inbox", NavigationPath = CreateNavigationPath(NavigationParametersInfo.Inbox) });
            root.Items.Add(new NavigationItem() { Caption = "Drafts", NavigationPath = CreateNavigationPath(NavigationParametersInfo.Drafts) });
            root.Items.Add(new NavigationItem() { Caption = "Sent Items", NavigationPath = CreateNavigationPath(NavigationParametersInfo.Sent) });
            root.Items.Add(new NavigationItem() { Caption = "Deleted Items", NavigationPath = CreateNavigationPath(NavigationParametersInfo.Deleted) });

            Items.Add(root);
        }


        private string CreateNavigationPath(string folder)
        {
            // URIQUERY changed to NavigationParameters
            var query = new NavigationParameters();
            query.Add(NavigationParametersInfo.FolderKey, folder);
            return typeof(MailView).FullName + query;
        }
    }
}
