﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using IgOutlook;
using Telerik.Windows.Controls;
using IgOutlook.Infrastructure;
namespace IGOutlook
{
    /// <summary>
    /// Interaction logic for Shell.xaml
    /// </summary>
    public partial class Shell : RadRibbonWindow
    {
        public Shell(ShellViewModel viewModel)
        {
            InitializeComponent();
            DataContext = viewModel;
        }

        private void XamOutlookBar_SelectedGroupChanged(object sender, SelectionChangedEventArgs e)
        {
            var selectedItem = ((RadOutlookBar)sender).SelectedItem as IOutlookBarGroup;

            if (selectedItem != null)
            {
              Commands.NavigateCommand.Execute(selectedItem.DefaultNavigationPath);
            }
        }
        //private void XamOutlookBar_SelectedGroupChanged(object sender, System.Windows.RoutedEventArgs e)
        //{
        //    var group = ((RadOutlookBar)sender).SelectedGroup as IOutlookBarGroup;
        //    if (group != null)
        //    {
        //        Commands.NavigateCommand.Execute(group.DefaultNavigationPath);
        //    }
        //}
    }
}
