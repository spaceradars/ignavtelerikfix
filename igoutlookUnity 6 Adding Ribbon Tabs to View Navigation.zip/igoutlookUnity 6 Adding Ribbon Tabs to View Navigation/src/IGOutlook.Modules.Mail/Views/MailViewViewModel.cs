﻿using IgOutlook.Infrastructure;
using Prism.Events;
using Prism.Regions;

namespace IgOutlook.Modules.Mail.Views
{
    public interface IMailViewViewModel : IgOutlook.Infrastructure.IViewModel
    {

    }

    public class MailViewViewModel : NavigationAwareViewModelBase, IMailViewViewModel
    {
        private readonly IEventAggregator _eventAggregator;

        public MailViewViewModel(IEventAggregator eventAggragator)
        {
            _eventAggregator = eventAggragator;
        }

        public override void OnNavigatedTo(NavigationContext navigationContext)
        {
            Title = $"IG Outlook - {navigationContext.Parameters[NavigationParametersInfo.FolderKey]}";
            base.OnNavigatedTo(navigationContext);

            // NOT NEEDED TO SHOW TITLE
            _eventAggregator.GetEvent<ViewActivateEvent>().Publish(Title);
        }
    }
   
}
