﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IGOutlook.Modules.Mail
{
    public class Class1
    {
    }
}
