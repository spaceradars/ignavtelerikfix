﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using IgOutlook.Infrastructure;
using IGOutlook.Infrastructure;
using Prism.Commands;
using Prism.Events;
using Prism.Regions;

namespace IgOutlook
{
    public class ShellViewModel : ViewModelBase
    {
        private IRegionManager _regionManager;

        public DelegateCommand<String> NavigateCommand { get; set; }

        public ShellViewModel(IRegionManager regionManager, IEventAggregator eventAggregator)
        {
            _regionManager = regionManager;

            NavigateCommand = new DelegateCommand<String>(Navigate);
            Commands.NavigateCommand.RegisterCommand(NavigateCommand);

        }

        private void Navigate(string navigationPath)
        {
            if (string.IsNullOrWhiteSpace(navigationPath))
                return;

            if (!String.IsNullOrWhiteSpace(navigationPath))
                _regionManager.RequestNavigate(RegionNames.ContentRegion, navigationPath);
        }
    }
}
