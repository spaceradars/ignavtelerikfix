﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Prism.Regions;
using Telerik.Windows.Controls;


namespace IgOutlook.Infrastructure.Prism
{
    public class XamOutlookBarRegionAdapter : RegionAdapterBase<RadOutlookBar>
    {
        public XamOutlookBarRegionAdapter(IRegionBehaviorFactory factory)
            : base (factory)
        {

        }

        protected override void Adapt(IRegion region, RadOutlookBar regionTarget)
        {
            region.ActiveViews.CollectionChanged += ((x, y) =>
                {
                    switch (y.Action)
                    {
                        case System.Collections.Specialized.NotifyCollectionChangedAction.Add:
                            {
                                foreach (RadOutlookBarItem group in y.NewItems)
                                {
                                    regionTarget.Items.Add(group);

#if !SILVERLIGHT
                                //The WPF XamOutlookBar does not automatically select the first group in it's collection.
                                //So we must manually select the group if it is the first one in the collection, but we don't
                                //want to excute this code every time a new group is added, only if the first group is the current group being added.
                                if (regionTarget.Items[0] == group)
                                {
                                    regionTarget.SelectedItem = group;
                                }
#endif

                                }
                                break;
                            }
                        case System.Collections.Specialized.NotifyCollectionChangedAction.Remove:
                            {
                                foreach (RadOutlookBarItem group in y.OldItems)
                                {
                                    regionTarget.Items.Remove(group);
                                }
                                break;
                            }
                    }
                });
        }

        protected override IRegion CreateRegion()
        {
            return new AllActiveRegion();
        }
    }
}
