﻿using System.Collections.Generic;
using System.Linq;
using System.Windows.Controls;
using IGOutlook.Infrastructure;
//using Microsoft.Practices.Prism.Regions;
//using Microsoft.Practices.Prism.Events;
using Prism.Events;
using Prism.Regions;

namespace IgOutlook.Infrastructure
{
    public class ViewBase : UserControl, IViewBase, INavigationAware
    {
        protected IRegionManager RegionManager { get; private set; }
        protected IEventAggregator EventAggregator { get; private set; }
        public IList<IRibbonTabItem> RibbonTabs { get; private set; }

        public IViewModel ViewModel
        {
            get { return (IViewModel)DataContext; }
            set { DataContext = value; }
        }

        public ViewBase()
        {
            RibbonTabs = new List<IRibbonTabItem>();
        }

        public ViewBase(IViewModel viewModel)
            : this()
        {
            ViewModel = viewModel;
        }

        public ViewBase(IRegionManager regionManager)
            : this()
        {
            RegionManager = regionManager;
        }

        public ViewBase(IViewModel viewModel, IRegionManager regionManager)
            : this(viewModel)
        {
            RegionManager = regionManager;
        }

        public ViewBase(IViewModel viewModel, IEventAggregator eventAggregator)
            : this(viewModel)
        {
            EventAggregator = eventAggregator;
        }

        public ViewBase(IViewModel viewModel, IRegionManager regionManager, IEventAggregator eventAggregator)
            : this(viewModel, regionManager)
        {
            EventAggregator = eventAggregator;
        }



        public virtual bool IsNavigationTarget(NavigationContext navigationContext)
        {
            return true;
        }

        /// <summary>
        /// Navigating away  from view remove tabs away from region
        /// </summary>
        /// <param name="navigationContext"></param>
        public virtual void OnNavigatedFrom(NavigationContext navigationContext)
        {
            if (RegionManager != null)
            {
                IRegion tabRegion = RegionManager.Regions[RegionNames.RibbonTabRegion];
                RibbonTabs.ToList().ForEach(tabRegion.Remove);
            }
        }

        /// <summary>
        /// Navigating to view add ribbon  tabs to region
        /// </summary>
        /// <param name="navigationContext"></param>
        public virtual void OnNavigatedTo(NavigationContext navigationContext)
        {
            //Navigating to view add ribbon  tabs to region
            if (RegionManager != null)
            {
                IRegion tabRegion = RegionManager.Regions[RegionNames.RibbonTabRegion];
                RibbonTabs.ToList().ForEach(tab => tabRegion.Add(tab));
            }


            if (EventAggregator != null)
                EventAggregator.GetEvent<ViewActivateEvent>().Publish(ViewModel.Title);
        }
    }
}
