﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel.Composition;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Prism.Regions;
using Telerik.Windows.Controls;

namespace IGOutlook.Infrastructure.Prism
{
    
    //[Export(typeof(XamlRibbonRegionAdapter))]
    public class XamlRibbonRegionAdapter : RegionAdapterBase<RadRibbonView>
    {
       // [ImportingConstructor]
        public XamlRibbonRegionAdapter(IRegionBehaviorFactory regionBehaviorFactory)
            : base(regionBehaviorFactory)
        { }

        // Adapting control to accept veiws

        protected override void Adapt(IRegion region, RadRibbonView regionTarget)
        {
           if(region==null) throw new ArgumentException("region");
           if (regionTarget == null) throw new ArgumentException("regionTarget");
            region.ActiveViews.CollectionChanged += ((s, args) =>
            {
                switch (args.Action)
                {
                    case NotifyCollectionChangedAction.Add:
                        {
                            foreach (var view in args.NewItems)
                            {
                                AddViewToRegion(view, regionTarget);
                            }
                        }
                        break;
                    case NotifyCollectionChangedAction.Remove:
                        {
                            foreach (var view in args.NewItems)
                            {
                                RemoveiewToRegion(view, regionTarget);
                            }
                        }
                        break;
                }
            });
        }

        /// <summary>
        /// Ask what kind of region is this will just contain content control or multiple views
        /// </summary>
        /// <returns></returns>
        protected override IRegion CreateRegion()
        {
            return new AllActiveRegion();
        }

        static void AddViewToRegion(object view, RadRibbonView xmlRibbon)
        {
            
        }

        static void RemoveiewToRegion(object view, RadRibbonView xmlRibbon)
        {

        }
    }

}
