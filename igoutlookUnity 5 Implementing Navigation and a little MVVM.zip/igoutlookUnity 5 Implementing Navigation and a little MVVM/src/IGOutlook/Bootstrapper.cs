﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using Microsoft.Practices.Unity;
using Prism.Unity;
using IGOutlook.Modules.Mail;
using Prism.Modularity;
using Prism.Regions;
using Telerik.Windows.Controls;
using IGOutlook.Infrastructure.Prism;
//using Microsoft.Practices.Prism.UnityExtensions;
//using Microsoft.Practices.Prism.Modularity;
namespace IGOutlook
{
    public class Bootstrapper : UnityBootstrapper
    {
        protected override DependencyObject CreateShell()
        {
            return Container.Resolve<Shell>();
        }

        protected override void InitializeShell()
        {
            base.InitializeShell();

            Application.Current.MainWindow = (Window)Shell;
            Application.Current.MainWindow.Show();
        }

        protected override IModuleCatalog CreateModuleCatalog()
        {
            var catalog = new ModuleCatalog();
            catalog.AddModule(typeof(MailModule));
            return catalog;
        }

        protected override RegionAdapterMappings ConfigureRegionAdapterMappings()
        {
            // Gives Default mappings 
            RegionAdapterMappings mappings = base.ConfigureRegionAdapterMappings();

            mappings.RegisterMapping(typeof(RadOutlookBar), Container.Resolve<XamlOutlookBarRegionAdapter>());
            mappings.RegisterMapping(typeof(RadRibbonView), Container.Resolve<XamlRibbonRegionAdapter>());
            return mappings;
        }
    }

}
