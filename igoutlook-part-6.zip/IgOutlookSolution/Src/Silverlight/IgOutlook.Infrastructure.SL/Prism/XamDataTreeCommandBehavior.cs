﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Practices.Prism.Commands;
using Infragistics.Controls.Menus;

namespace IgOutlook.Infrastructure.Prism
{
    public class XamDataTreeCommandBehavior : CommandBehaviorBase<XamDataTree>
    {
        public XamDataTreeCommandBehavior(XamDataTree tree)
            : base(tree)
        {
            tree.ActiveNodeChanged += TreeActive_NodeChanged;
        }

        void TreeActive_NodeChanged(object sender, ActiveNodeChangedEventArgs e)
        {
            var param = e.NewActiveTreeNode.Data as INavigationItem;
            if (param != null)
                CommandParameter = param.NavigationPath;
            else
                CommandParameter = String.Empty;

            ExecuteCommand();
        }
    }
}
