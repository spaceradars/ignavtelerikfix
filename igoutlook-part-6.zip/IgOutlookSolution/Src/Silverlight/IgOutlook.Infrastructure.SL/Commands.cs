﻿using Microsoft.Practices.Prism.Commands;

namespace IgOutlook.Infrastructure
{
    public class Commands
    {
        public static CompositeCommand NavigateCommand = new CompositeCommand();
    }
}
