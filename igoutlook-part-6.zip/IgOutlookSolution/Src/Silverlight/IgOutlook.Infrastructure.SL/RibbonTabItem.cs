﻿using Infragistics.Controls.Menus;

namespace IgOutlook.Infrastructure
{
#if !SILVERLIGHT
    public class RibbonTabItem : Infragistics.Windows.Ribbon.RibbonTabItem, IRibbonTabItem
#else
    public class RibbonTabItem : Infragistics.Controls.Menus.XamRibbonTabItem, IRibbonTabItem
#endif
    {
        public IViewModel ViewModel
        {
            get
            {
                return (IViewModel)DataContext;
            }
            set
            {
                DataContext = value;
            }
        }
    }
}
