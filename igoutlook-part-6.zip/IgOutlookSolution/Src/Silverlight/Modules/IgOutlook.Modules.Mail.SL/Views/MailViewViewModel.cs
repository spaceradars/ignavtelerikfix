﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using IgOutlook.Infrastructure;
using Microsoft.Practices.Prism.Events;

namespace IgOutlook.Modules.Mail.Views
{
    public interface IMailViewViewModel : IViewModel
    {

    }

    public class MailViewViewModel : NavigationAwareViewModelBase, IMailViewViewModel
    {
        private readonly IEventAggregator _eventAggregator;

        public MailViewViewModel(IEventAggregator eventAggragator)
        {
            _eventAggregator = eventAggragator;
        }

        public override void OnNavigatedTo(Microsoft.Practices.Prism.Regions.NavigationContext navigationContext)
        {
            Title = String.Format("IG Outlook - {0}", navigationContext.Parameters[NavigationParameters.FolderKey]);
            base.OnNavigatedTo(navigationContext);

            _eventAggregator.GetEvent<ViewActivateEvent>().Publish(Title);
        }
    }
}
