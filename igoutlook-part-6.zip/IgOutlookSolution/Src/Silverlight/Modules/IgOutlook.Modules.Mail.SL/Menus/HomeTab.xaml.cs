﻿
namespace IgOutlook.Modules.Mail.Menus
{
    public partial class HomeTab
    {
        public HomeTab()
        {
            InitializeComponent();
        }
    }
}
