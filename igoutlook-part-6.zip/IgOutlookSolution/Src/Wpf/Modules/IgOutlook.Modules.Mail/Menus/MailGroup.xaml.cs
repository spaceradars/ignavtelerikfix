﻿using IgOutlook.Infrastructure;
using Infragistics.Controls.Menus;
using Infragistics.Windows.OutlookBar;
using IgOutlook.Modules.Mail.Views;

namespace IgOutlook.Modules.Mail.Menus
{
    /// <summary>
    /// Interaction logic for MailGroup.xaml
    /// </summary>
    public partial class MailGroup : OutlookBarGroup, IOutlookBarGroup
    {
        public MailGroup(MailGroupViewModel viewModel)
        {
            InitializeComponent();
            DataContext = viewModel;
        }

        public string DefaultNavigationPath
        {
            get
            {
                var item = _xamDataTree.SelectionSettings.SelectedNodes[0] as XamDataTreeNode;
                if (item != null)
                    return ((INavigationItem)item.Data).NavigationPath;
                else
                    return typeof(DefaultView).FullName;
            }
        }
    }
}
